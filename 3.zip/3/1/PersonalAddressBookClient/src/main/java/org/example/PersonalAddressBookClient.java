package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class PersonalAddressBookClient {
    private static final String SERVER_ADDRESS = "localhost"; // 服务器地址
    private static final int SERVER_PORT = 12345; // 服务器端口

    public static void main(String[] args) {
        try {
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            String userInput;

            // 客户端主循环
            while (true) {
                System.out.println("请选择操作：");
                System.out.println("1. 查看联系人信息");
                System.out.println("2. 添加新联系人");
                System.out.println("3. 修改联系人信息");
                System.out.println("4. 删除联系人");
                System.out.println("0. 退出");

                userInput = reader.readLine();

                if (userInput.equals("0")) {
                    break;
                } else if (userInput.equals("1")) {
                    out.println("VIEW"); // 发送查看联系人信息的请求给服务器
                    String response = in.readLine(); // 接收服务器的响应
                    System.out.println(response); // 打印联系人信息
                } else if (userInput.equals("2")) {
                    System.out.println("请输入联系人姓名：");
                    String name = reader.readLine();
                    System.out.println("请输入联系人住址：");
                    String address = reader.readLine();
                    System.out.println("请输入联系人电话：");
                    String phoneNumber = reader.readLine();

                    // 构造添加联系人的请求消息，并发送给服务器
                    out.println("ADD " + name + " " + address + " " + phoneNumber);
                    String response = in.readLine(); // 接收服务器的响应
                    System.out.println(response); // 打印添加联系人结果
                } else if (userInput.equals("3")) {
                    System.out.println("请输入要修改的联系人姓名：");
                    String name = reader.readLine();
                    System.out.println("请输入新的联系人住址：");
                    String address = reader.readLine();
                    System.out.println("请输入新的联系人电话：");
                    String phoneNumber = reader.readLine();

                    // 构造修改联系人的请求消息，并发送给服务器
                    out.println("UPDATE " + name + " " + address + " " + phoneNumber);
                    String response = in.readLine(); // 接收服务器的响应
                    System.out.println(response); // 打印修改联系人结果
                } else if (userInput.equals("4")) {
                    System.out.println("请输入要删除的联系人姓名：");
                    String name = reader.readLine();

                    // 构造删除联系人的请求消息，并发送给服务器
                    out.println("DELETE " + name);
                    String response = in.readLine(); // 接收服务器的响应
                    System.out.println(response); // 打印删除联系人结果
                } else {
                    System.out.println("无效的输入，请重新输入。");
                }
            }

            // 关闭连接
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}