package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PersonalAddressBookServer {
    private static final int SERVER_PORT = 12345; // 服务器端口
    private static final String DB_URL = "jdbc:mysql://localhost:3306/address_book"; // 数据库连接URL
    private static final String DB_USERNAME = "root"; // 数据库用户名
    private static final String DB_PASSWORD = "123456"; // 数据库密码

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            System.out.println("服务器已启动，等待客户端连接...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("客户端连接成功：" + clientSocket.getInetAddress());

                new ClientHandler(clientSocket).start(); // 启动客户端处理线程
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket clientSocket;
        private Connection connection;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

                connectToDatabase(); // 连接数据库

                String clientMessage;

                while ((clientMessage = in.readLine()) != null) {
                    if (clientMessage.equals("VIEW")) {
                        String response = viewContacts(); // 查看联系人信息
                        out.println(response); // 发送联系人信息给客户端
                    } else if (clientMessage.startsWith("ADD")) {
                        String[] contactInfo = clientMessage.substring(4).split(" ");
                        String response = addContact(contactInfo[0], contactInfo[1], contactInfo[2]); // 添加联系人
                        out.println(response); // 发送添加联系人结果给客户端
                    } else if (clientMessage.startsWith("UPDATE")) {
                        String[] contactInfo = clientMessage.substring(7).split(" ");
                        String response = updateContact(contactInfo[0], contactInfo[1], contactInfo[2]); // 修改联系人信息
                        out.println(response); // 发送修改联系人结果给客户端
                    } else if (clientMessage.startsWith("DELETE")) {
                        String name = clientMessage.substring(7);
                        String response = deleteContact(name); // 删除联系人
                        out.println(response); // 发送删除联系人结果给客户端
                    } else {
                        System.out.println("无效的请求：" + clientMessage);
                    }
                }

                closeConnection(); // 关闭数据库连接
                clientSocket.close(); // 关闭客户端连接
                System.out.println("客户端断开连接：" + clientSocket.getInetAddress());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private void connectToDatabase() {
            try {
                connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                System.out.println("数据库连接成功");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        private String viewContacts() {
            StringBuilder sb = new StringBuilder();

            try {
                PreparedStatement statement = connection.prepareStatement("SELECT * FROM contacts");
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    String name = resultSet.getString("name");
                    String address = resultSet.getString("address");
                    String phoneNumber = resultSet.getString("phone_number");
                    sb.append("姓名：").append(name)
                            .append(" 住址：").append(address)
                            .append(" 电话：").append(phoneNumber)
                            .append("\t");
                }

                resultSet.close();
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return sb.toString();
        }

        private String addContact(String name, String address, String phoneNumber) {
            try {
                PreparedStatement statement = connection.prepareStatement("INSERT INTO contacts (name, address, phone_number) VALUES (?, ?, ?)");
                statement.setString(1, name);
                statement.setString(2, address);
                statement.setString(3, phoneNumber);
                statement.executeUpdate();
                statement.close();
                return "添加联系人成功";
            }catch (SQLException e) {
                e.printStackTrace();
                return "添加联系人失败";
            }
        }

        private String updateContact(String name, String address, String phoneNumber) {
            try {
                PreparedStatement statement = connection.prepareStatement("UPDATE contacts SET address = ?, phone_number = ? WHERE name = ?");
                statement.setString(1, address);
                statement.setString(2, phoneNumber);
                statement.setString(3, name);
                int rowsAffected = statement.executeUpdate();
                statement.close();

                if (rowsAffected > 0) {
                    return "修改联系人信息成功";
                } else {
                    return "找不到指定的联系人：" + name;
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return "修改联系人信息失败";
            }
        }

        private String deleteContact(String name) {
            try {
                PreparedStatement statement = connection.prepareStatement("DELETE FROM contacts WHERE name = ?");
                statement.setString(1, name);
                int rowsAffected = statement.executeUpdate();
                statement.close();

                if (rowsAffected > 0) {
                    return "删除联系人成功";
                } else {
                    return "找不到指定的联系人：" + name;
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return "删除联系人失败";
            }
        }

        private void closeConnection() {
            try {
                if (connection != null) {
                    connection.close();
                    System.out.println("数据库连接已关闭");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}