package org.example;

import java.util.List;
import java.util.Scanner;

public class Client {
    private ContactService contactService;

    public Client() {
        contactService = new ContactService();
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("请选择操作：1.查看联系人信息 2.添加新联系人 3.修改联系人信息 4.删除联系人 5.退出");
            int operation = scanner.nextInt();
            switch (operation) {
                case 1:
                    /*System.out.println("请输入联系人ID：");
                    int id = scanner.nextInt();*/
                    List<Contact> contacts = contactService.getAllContact();
                    for (Contact contact : contacts) {
                        System.out.println("ID: " + contact.getId() + ", Name: " + contact.getName() + ", Phone: " + contact.getPhone());
                    }
                    break;
                case 2:
                    System.out.println("请输入联系人姓名：");
                    String name = scanner.next();
                    System.out.println("请输入联系人电话：");
                    String phone = scanner.next();
                    Contact newContact = new Contact(name, phone);
                    contactService.addContact(newContact);
                    System.out.println("联系人添加成功！");
                    break;
                case 3:
                    System.out.println("请输入联系人ID：");
                    int updateId = scanner.nextInt();
                    Contact updateContact = contactService.getContact(updateId);
                    if (updateContact != null) {
                        System.out.println("请输入新的联系人姓名：");
                        String updateName = scanner.next();
                        System.out.println("请输入新的联系人电话：");
                        String updatePhone = scanner.next();
                        updateContact.setName(updateName);
                        updateContact.setPhone(updatePhone);
                        contactService.updateContact(updateContact);
                        System.out.println("联系人信息修改成功！");
                    } else {
                        System.out.println("联系人不存在！");
                    }
                    break;
                case 4:
                    System.out.println("请输入要删除的联系人ID：");
                    int deleteId = scanner.nextInt();
                    contactService.deleteContact(deleteId);
                    System.out.println("联系人删除成功！");
                    break;
                case 5:
                    System.out.println("程序已退出。");
                    System.exit(0);
                    break;
                default:
                    System.out.println("无效的操作！");
            }
        }
    }
}