package org.example;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ContactDAO {
    private String dbURL = "jdbc:mysql://localhost:3306/mydatabase";
    private String dbUser = "root";
    private String dbPassword = "123456";

    public void addContact(Contact contact) {
        try {
            Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO contacts (name, phone) VALUES (?, ?)");
            pstmt.setString(1, contact.getName());
            pstmt.setString(2, contact.getPhone());
            pstmt.executeUpdate();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateContact(Contact contact) {
        try {
            Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);
            PreparedStatement pstmt = conn.prepareStatement("UPDATE contacts SET name = ?, phone = ? WHERE id = ?");
            pstmt.setString(1, contact.getName());
            pstmt.setString(2, contact.getPhone());
            pstmt.setInt(3, contact.getId());
            pstmt.executeUpdate();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteContact(int id) {
        try {
            Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);
            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM contacts WHERE id = ?");
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Contact getContact(int id) {
        Contact contact = null;
        try {
            Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM contacts WHERE id = ?");
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                contact = new Contact();
                contact.setId(id);
                contact.setName(rs.getString("name"));
                contact.setPhone(rs.getString("phone"));
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return contact;
    }

    public List<Contact> getAllContact() {
        List<Contact> contacts = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM contacts");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Contact contact = new Contact();
                contact.setId(rs.getInt("id"));
                contact.setName(rs.getString("name"));
                contact.setPhone(rs.getString("phone"));
                contacts.add(contact);
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return contacts;
    }
}
