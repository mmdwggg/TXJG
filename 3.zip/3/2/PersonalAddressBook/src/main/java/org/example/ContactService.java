package org.example;

import java.util.List;

public class ContactService {
    private ContactDAO contactDAO;

    public ContactService() {
        contactDAO = new ContactDAO();
    }

    public void addContact(Contact contact) {
        contactDAO.addContact(contact);
    }

    public void updateContact(Contact contact) {
        contactDAO.updateContact(contact);
    }

    public void deleteContact(int id) {
        contactDAO.deleteContact(id);
    }

    public Contact getContact(int id) {
        return contactDAO.getContact(id);
    }

    public List<Contact> getAllContact() {
        return contactDAO.getAllContact();
    }
}