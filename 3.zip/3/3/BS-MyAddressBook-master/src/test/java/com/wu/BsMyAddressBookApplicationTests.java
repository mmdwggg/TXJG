package com.wu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BsMyAddressBookApplicationTests {

    @Test
    void contextLoads() {
    }

}
