package com.example.back.control;


import com.example.back.pojo.Result;

import com.example.back.service.service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;


@Slf4j
@RequestMapping("/sds")
@RestController
public class DeptController {

    private service service;

    @GetMapping
    public Result save(double num){
        System.out.println(num);
        service=new service(num);
        double money=service.getSds();
        return Result.success(money);
    }
}

