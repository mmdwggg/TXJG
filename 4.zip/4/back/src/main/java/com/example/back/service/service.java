package com.example.back.service;

public class service {
    double money,sds;
    public service(double money){
        this.money=money;
    }

    public double getSds(){
        if (money > 5000) {
            double money1=money-5000;
            if (money1 > 0 && money1 <= 3000) {
                this.sds = money1 * 0.03;
            } else if (money1 > 3000 && money1 <= 12000) {
                this.sds = (money1 - 3000) * 0.1 + 3000 * 0.03;
            } else if (money1 > 12000 && money1 <= 25000) {
                this.sds = (money1 - 12000) * 0.2 + 3000 * 0.03 + 9000 * 0.1;
            } else if (money1 > 25000 && money1 <= 35000) {
                this.sds = (money1 - 25000) * 0.25 + 3000 * 0.03 + 9000 * 0.1 + 13000 * 0.2;
            } else if (money1 > 35000 && money1 <= 55000) {
                this.sds = (money1 - 35000) * 0.3 + 3000 * 0.03 + 9000 * 0.1 + 13000 * 0.2 + 10000 * 0.25;
            } else if (money1 > 55000 && money1 <= 80000) {
                this.sds = (money1 - 55000) * 0.35 + 3000 * 0.03 + 9000 * 0.1 + 13000 * 0.2 + 10000 * 0.25 + 20000 * 0.3;
            } else {
                this.sds = (money1 - 80000) * 0.45 + 3000 * 0.03 + 9000 * 0.1 + 13000 * 0.2 + 10000 * 0.25 + 20000 * 0.3 + 25000 * 0.35;
            }
        } else {
            this.sds=0;
            }
        return this.sds;
    }
}
