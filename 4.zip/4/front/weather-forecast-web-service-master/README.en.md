# 四川省天气预报系统

#### Description
四川省天气预报系统，使用webservice架构，我的作业。

#### Software Architecture
使用webservice架构

#### Instructions
先运行tomcat再运行客户端
